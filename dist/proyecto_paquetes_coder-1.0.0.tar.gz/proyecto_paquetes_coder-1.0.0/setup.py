from setuptools import setup

setup (

name='proyecto_paquetes_coder',
version= '1.0.0',
description='prctica de paquetes y modulos',
author='Mauro Alberelli Comisión Python: 43875',
author_email='mauroalberelli@gmail.com',

packages=['proyecto_paquetes_coder']

)